# Foresight Bot - Advanced Farlight 84 Scrims Manager

## Overview
A comprehensive Discord bot for managing Farlight 84 competitive scrims with advanced features including thread-based team registration, dynamic lobby management, timed check-ins with captcha verification, and automated slot list generation.

## Recent Changes (October 18, 2025)
- ✅ Complete bot implementation with all advanced features
- ✅ Installed Node.js 20 and all dependencies (discord.js v14, express, canvas, sqlite3, moment-timezone, node-cron, dotenv)
- ✅ Implemented thread-based team registration with 6-step validation flow
- ✅ Created multi-day scrim scheduling system (admin commands)
- ✅ Built timed 'Register Here' channel with automatic permission management
- ✅ Implemented word-based captcha verification for check-ins (60s timeout)
- ✅ Created dynamic lobby system (auto-creates Lobby-1, Lobby-2, etc. for 20 teams each)
- ✅ Added lobby role assignment and transfer system
- ✅ Built automated slot list generation and posting to lobby channels
- ✅ Implemented Canvas-based leaderboard generation with professional graphics
- ✅ Set up SQLite3 database with 5 tables for persistent storage
- ✅ Added Express server on port 3000 for 24/7 uptime monitoring
- ✅ Installed system dependencies (libuuid, cairo, pango, etc.) for Canvas support
- ✅ Bot successfully tested and running online

## Project Architecture

### Core Features
1. **Thread-Based Team Registration**
   - 6 sequential questions in Discord threads
   - Team name, tag validation ([ABC] format, 6-char alphanumeric)
   - Player 1-3 details with UID format (Player#12345678)
   - Automatic eSports role assignment after 3 valid teammate mentions

2. **Multi-Day Scrim Scheduling**
   - Checkbox selection for different days
   - Multiple time slots per day
   - Automated check-in window management

3. **Timed Check-In System**
   - 'Register Here' channel locks/unlocks automatically
   - Check-in button appears at scheduled times
   - Word-based captcha verification
   - Only registered teams (eSports role) can access

4. **Dynamic Lobby Management**
   - Auto-create Lobby-1, Lobby-2, etc. (20 teams per lobby)
   - Lobby-specific role assignment on check-in
   - Role transfer system between teammates
   - Automated slot list posting to lobby channels

5. **Canvas Leaderboards**
   - Professional leaderboard image generation
   - Team rankings with kills and placement points

6. **24/7 Uptime**
   - Express server on port 3000
   - Health check endpoint for monitoring

### Database Schema (SQLite3)
- **teams**: team_name, team_tag, captain_id, player IDs, substitute
- **scrims**: scrim_name, days, start_time, end_time, mention_role_id
- **daily_registration**: scrim_name, team_name, checked_in, lobby_number
- **lobby_assignments**: scrim_date, lobby_number, team_name, check_in_order
- **captcha_tracking**: user_id, scrim_name, captcha_word, verified

### Tech Stack
- Discord.js v14 - Discord API interactions
- Express.js - Health check server
- Canvas - Leaderboard image generation
- SQLite3 - Database management
- moment-timezone - Timezone handling
- node-cron - Scheduled tasks
- dotenv - Environment configuration

## User Preferences
- Server timezone: Asia/Kolkata (configurable)
- Port 3000 for Express server
- Captain-only team edit/delete permissions (admins can override)
- Automated role cleanup after scrims

## Setup Instructions
1. Set up environment variables in `.env` file (see `.env.example`)
2. Configure DISCORD_TOKEN and GUILD_ID
3. Run `node index.js` to start the bot
4. Bot will auto-create necessary channels and roles on first run
